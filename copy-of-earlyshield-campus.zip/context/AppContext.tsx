import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Signal, Stats, Zone } from '../types';
import { INITIAL_SIGNALS, INITIAL_STATS, ZONES } from '../services/mockData';

interface AppContextType {
  signals: Signal[];
  stats: Stats;
  zones: Zone[];
  addSignal: (signal: Signal) => void;
  updateSignalStatus: (id: string, status: Signal['status']) => void;
  isDark: boolean;
  toggleTheme: () => void;
  userType: 'Admin' | 'Student' | 'Management';
  setUserType: (type: 'Admin' | 'Student' | 'Management') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [signals, setSignals] = useState<Signal[]>(INITIAL_SIGNALS);
  const [stats, setStats] = useState<Stats>(INITIAL_STATS);
  const [zones] = useState<Zone[]>(ZONES);
  const [isDark, setIsDark] = useState(false);
  const [userType, setUserType] = useState<'Admin' | 'Student' | 'Management'>('Admin');

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(prev => !prev);

  const addSignal = (signal: Signal) => {
    setSignals((prev) => [signal, ...prev]);
    setStats((prev) => ({
      ...prev,
      activeSignals: prev.activeSignals + 1,
      healthScore: Math.max(0, prev.healthScore - (signal.riskLevel === 'Critical' ? 5 : 2)),
    }));
  };

  const updateSignalStatus = (id: string, status: Signal['status']) => {
    setSignals((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
  };

  return (
    <AppContext.Provider value={{ signals, stats, zones, addSignal, updateSignalStatus, isDark, toggleTheme, userType, setUserType }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};